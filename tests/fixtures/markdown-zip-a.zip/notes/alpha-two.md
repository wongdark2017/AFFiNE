# Alpha Two

Content of alpha two in notes folder.
